This is the older rusEfi board which is not really being developed any more.

See [Frankenso](../frankenso) for the next generation of official rusEfi hardware

See also [Board Comparison](https://rusefi.com/wiki/index.php?title=Hardware:For_Sale)